package projetoMarmita.com.br;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoMarmitaApplicationTests {

	@Test
	void contextLoads() {
	}

}
