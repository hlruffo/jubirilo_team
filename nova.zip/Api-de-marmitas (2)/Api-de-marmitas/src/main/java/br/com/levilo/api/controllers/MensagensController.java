package br.com.levilo.api.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.levilo.api.dtos.MensagemDTO;
import br.com.levilo.api.service.WhatsappService;

@RestController
@RequestMapping("/api/mensagens")
public class MensagensController {

	@Autowired
	private ProdutosController produtosController;
	
	@Autowired
	private WhatsappService whatsappService;

	@Value("${cliente.nome}")
	String clienteNome;
	
	@PostMapping("/enviar")
	public String enviarMensagemWhatsapp() throws Exception {
		
		MensagemDTO mensagemDTO = new MensagemDTO();
		mensagemDTO.setLink("https://levilo.com/thaifitdelivery");
		mensagemDTO.setNomeUsuario(clienteNome);
		mensagemDTO.setProdutoMaisVendido(produtosController.getMaisVendido().getNome());
		mensagemDTO.setProdutoMenosVendido(produtosController.getMenosVendido().getNome());
		
		if(whatsappService.sendMessage(mensagemDTO))
			return "Mensagem enviada com sucesso.";
		else
			return "Erro ao enviar mensagem";
	}
}
