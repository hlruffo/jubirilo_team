package br.com.levilo.api.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WhatsappOptionsDTO {
	
	@JsonProperty("delay")
	private Integer delay;

	@JsonProperty("presence")
	private String presence;
}
