package br.com.levilo.api.service;

import org.apache.http.HttpResponse;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

@Service
public class ChatGPTService {
	
	private static final String GPT_API_URL = "https://api.openai.com/v1/engines/davinci/completions";
	private static final String API_KEY = "SUA_API_KEY_DO_CHATGPT"; // Substitua pela sua chave API

	public String enviarPrompt(String prompt) {
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			HttpPost request = new HttpPost(GPT_API_URL);
			request.addHeader("Authorization", "Bearer " + API_KEY);

			String requestBody = "{\"prompt\": \"" + prompt + "\", \"max_tokens\": 50}";
			request.setEntity(new StringEntity(requestBody));

			HttpResponse response = httpClient.execute(request);
			HttpEntity entity = response.getEntity();

			if (entity != null) {

				return EntityUtils.toString(entity);
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return null;
	}
}
