package br.com.levilo.api.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.levilo.api.entities.Produto;
import br.com.levilo.api.repositories.ProdutoRepository;
import br.com.levilo.api.service.ChatGPTService;


@RestController
@RequestMapping("/api/chat")
public class ChatGPTController {
	
	@Autowired
	ProdutoRepository produtoRepository;
	
	private final ChatGPTService chatGPTService;

	public ChatGPTController(ChatGPTService chatGPTService) {
		this.chatGPTService = chatGPTService;
	}

	@PostMapping("/gerar-prompt")
	public String enviarPrompt() throws Exception {
		List<Produto> quantidadePorPedido = produtoRepository.obterQuantidadePorPedido(null, null);
		String prompt = "Considerando os dados de venda de "+quantidadePorPedido+", considere o item com maior e menor quantidade de vendas.\r\n"
				+ "\r\n"
				+ " Crie insights para melhoria do desempenho de vendas, considerando que o usuário não possui conhecimento técnico em gestão de empresas ou finanças. A linguagem utilizada deve ser a mais amigável possível neste contexto.\r\n"
				+ "\r\n"
				+ "são exemplos de insights: \r\n"
				+ "- gerar promoções regionais com produtos menos vendidos a fim de aumentar as vendas\r\n"
				+ "- gerar promoções de fidelização do cliente \r\n"
				+ "- manter estoque de material para produção dos itens mais vendidos\r\n"
				+ "- impulsionar a venda com a criação de combos de pedidos incluindo itens mais e menos vendidos";
		String respostaDoGPT = chatGPTService.enviarPrompt(prompt);
		return respostaDoGPT;
	}
}
