package br.com.levilo.api.factories;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {

	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String URL = "jdbc:mysql://marmitaria.mysql.uhserver.com:3306/marmitaria";
	private static final String USER = "marmitaria";
	private static final String PASS = "coti23@";
	
	public static Connection getConnection() throws Exception {
		Class.forName(DRIVER);
		return DriverManager.getConnection(URL, USER, PASS);
	}
}
