package br.com.levilo.api.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.levilo.api.dtos.MensagemDTO;
import br.com.levilo.api.dtos.WhatsappDTO;
import br.com.levilo.api.dtos.WhatsappOptionsDTO;
import br.com.levilo.api.dtos.WhatsappTextMessageDTO;

@Service
public class WhatsappService {

	@Value("${whatsapp.api.url}")
	String whatsappApiUrl;
	
	@Value("${whatsapp.api.key}")
	String whatsappApiKey;
	
	@Value("${cliente.numero}")
	String clienteNumero;
	
	public boolean sendMessage(MensagemDTO mensagemDTO) {
		
		WhatsappDTO whatsappDTO = new WhatsappDTO();
		whatsappDTO.setOptions(new WhatsappOptionsDTO());
		whatsappDTO.setTextMessage(new WhatsappTextMessageDTO());
		
		whatsappDTO.setNumber(clienteNumero);
		whatsappDTO.getOptions().setPresence("available");
		whatsappDTO.getOptions().setDelay(5000);
		
		StringBuilder text = new StringBuilder();
		text.append("Olá, " + mensagemDTO.getNomeUsuario());
		text.append("\nSeu produto mais vendido este mês foi: " + mensagemDTO.getProdutoMaisVendido());
		text.append("\nSeu produto menos vendido este mês foi: " + mensagemDTO.getProdutoMenosVendido());
		text.append("\nVeja a análise completa em: " + mensagemDTO.getLink());
		
		whatsappDTO.getTextMessage().setText(text.toString());
				
		return send(whatsappDTO).getStatusCode().is2xxSuccessful();
	}
	
	private ResponseEntity<String> send(WhatsappDTO whatsappDTO) {
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("apikey", whatsappApiKey);

		HttpEntity<WhatsappDTO> requestEntity = new HttpEntity<>(whatsappDTO, headers);

		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.postForEntity(whatsappApiUrl, requestEntity, String.class);
	}
}
