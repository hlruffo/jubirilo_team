package br.com.levilo.api.repositories;


import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.time.ZoneId;

import org.springframework.stereotype.Repository;

import br.com.levilo.api.entities.Produto;
import br.com.levilo.api.factories.ConnectionFactory;

@Repository
public class ProdutoRepository {
	
	public List<Produto> obterQuantidadePorPedido(LocalDate dataMin, LocalDate dataMax) throws Exception {
		
		String sql = "select "
				+ "p.codigo as codigo_produto, "
				+ "p.nome as nome_produto, "
				+ "count(ip.codigo) as qtd_vendas "
				+ "from produto p  "
				+ "inner join itempedido ip on p.codigo = ip.CodigoProduto "
				+ "inner join pedido pe on ip.codigopedido = pe.codigo "
				+ "where pe.datapedido between ? and ?"
				+ "group by p.codigo, p.nome "				
				+ "order by qtd_vendas desc";
		
		Connection connection = ConnectionFactory.getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, new SimpleDateFormat("yyyy-MM-dd").format(dataMin));
		statement.setString(2, new SimpleDateFormat("yyyy-MM-dd").format(dataMax));
		
		ResultSet resultSet = statement.executeQuery();
		List<Produto> produtos = new ArrayList<Produto>();
		
		while(resultSet.next()) {
			produtos.add(new Produto(
					resultSet.getInt("codigo_produto"),
					resultSet.getString("nome_produto"),
					resultSet.getInt("qtd_vendas")
					));
		}
		
		connection.close();
		return produtos;
	}	
	
	public Produto obterItemMaisVendido(LocalDate dataMin, LocalDate dataMax) throws Exception {
		
		String sql = "select "
				+ "p.codigo as codigo_produto, "
				+ "p.nome as nome_produto, "
				+ "count(ip.codigo) as qtd_vendas "
				+ "from produto p  "
				+ "inner join itempedido ip on p.codigo = ip.CodigoProduto "
				+ "inner join pedido pe on ip.codigopedido = pe.codigo "
				+ "where pe.datapedido between ? and ?"
				+ "group by p.codigo, p.nome "				
				+ "order by qtd_vendas desc limit 1";
		
		Date dateMin = Date.from(dataMin.atStartOfDay(ZoneId.systemDefault()).toInstant());
	    Date dateMax = Date.from(dataMax.atStartOfDay(ZoneId.systemDefault()).toInstant());
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	   
		Connection connection = ConnectionFactory.getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setString(1, sdf.format(dateMin));
	    statement.setString(2, sdf.format(dateMax));
		
		ResultSet resultSet = statement.executeQuery();
		Produto produto = null;
		
		if(resultSet.next()) {
			produto = new Produto(
					resultSet.getInt("codigo_produto"),
					resultSet.getString("nome_produto"),
					resultSet.getInt("qtd_vendas")
					);
		}
		
		connection.close();
		return produto;
	}	
	
	public Produto obterItemMenosVendido(LocalDate dataMin, LocalDate dataMax) throws Exception {
		
		String sql = "select "
				+ "p.codigo as codigo_produto, "
				+ "p.nome as nome_produto, "
				+ "count(ip.codigo) as qtd_vendas "
				+ "from produto p  "
				+ "inner join itempedido ip on p.codigo = ip.CodigoProduto "
				+ "inner join pedido pe on ip.codigopedido = pe.codigo "
				+ "where pe.datapedido between ? and ?"
				+ "group by p.codigo, p.nome "				
				+ "order by qtd_vendas asc limit 1";
		
		Date dateMin = Date.from(dataMin.atStartOfDay(ZoneId.systemDefault()).toInstant());
	    Date dateMax = Date.from(dataMax.atStartOfDay(ZoneId.systemDefault()).toInstant());

		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Connection connection = ConnectionFactory.getConnection();
	    PreparedStatement statement = connection.prepareStatement(sql);

		statement.setString(1, sdf.format(dateMin));
	    statement.setString(2, sdf.format(dateMax));
		ResultSet resultSet = statement.executeQuery();
		Produto produto = null;
		
		if(resultSet.next()) {
			produto = new Produto(
					resultSet.getInt("codigo_produto"),
					resultSet.getString("nome_produto"),
					resultSet.getInt("qtd_vendas")
					);
		}
		
		connection.close();
		return produto;
	}	
}