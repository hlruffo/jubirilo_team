package br.com.levilo.api.dtos;

import lombok.Data;

@Data
public class MensagemDTO {
	
	private String nomeUsuario;
	private String produtoMaisVendido;
	private String produtoMenosVendido;
	private String link;
}