package br.com.levilo.api.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WhatsappDTO {

	@JsonProperty("number")
	private String number;

	@JsonProperty("options")
	private WhatsappOptionsDTO options;

	@JsonProperty("textMessage")
	private WhatsappTextMessageDTO textMessage;

}
