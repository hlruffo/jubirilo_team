package br.com.levilo.api.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.levilo.api.entities.Produto;
import br.com.levilo.api.service.ProdutoService;

@Controller
@RestController("/api/produtos")
public class ProdutosController {

	
	@Autowired
	private ProdutoService produtoService;

	@GetMapping("/obter-quantidade-por-pedido")
	public List<Produto> getQuantidadePorPedido() throws Exception {

		return produtoService.getQuantidadePorPedido();

	}

	@GetMapping("/mais-vendido")
    public Produto getMaisVendido() throws Exception {
        return produtoService.getMaisVendido();
    }

	
	@GetMapping("/menos-vendido")
	public Produto getMenosVendido() throws Exception {
		return produtoService.getMenosVendido();
			    }
}
