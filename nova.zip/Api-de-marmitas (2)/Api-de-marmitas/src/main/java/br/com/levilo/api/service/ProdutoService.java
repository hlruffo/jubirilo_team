package br.com.levilo.api.service;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.levilo.api.entities.Produto;
import br.com.levilo.api.repositories.ProdutoRepository;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository produtoRepository;

	public List<Produto> getQuantidadePorPedido() throws Exception {
	    LocalDate primeiroDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
	    LocalDate ultimoDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());

	    // Chame o método do repository que retorna a lista de produtos
	    List<Produto> listaDeProdutos = produtoRepository.obterQuantidadePorPedido(primeiroDiaDoMesPassado, ultimoDiaDoMesPassado);

	    return listaDeProdutos;
	}

    

    public Produto getMaisVendido() throws Exception {
    	 LocalDate primeiroDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
         LocalDate ultimoDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());

        Produto produto = produtoRepository.obterItemMaisVendido(primeiroDiaDoMesPassado, ultimoDiaDoMesPassado);

       
            return produto;
       
    }

    public Produto getMenosVendido() throws Exception {
    	 LocalDate primeiroDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
         LocalDate ultimoDiaDoMesPassado = LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());

         Produto produto = produtoRepository.obterItemMenosVendido(primeiroDiaDoMesPassado, ultimoDiaDoMesPassado);

            return produto;
       
    }
}
